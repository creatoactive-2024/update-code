export const tableData = [
  { no: 1, client: "Sarah Johnson", airport: "JFK", driver: "Gafoor Pathan", type: "Arrival", datetime: "2025-10-21 14:00", status: "Driver Assigned", parkingSpot: "A12" },
  { no: 2, client: "Michael Jordan", airport: "LAX", driver: "Sam", type: "Departure", datetime: "2025-10-21 16:00", status: "In Progress", parkingSpot: "B02" },
  { no: 3, client: "Emily Rodriguez", airport: "ORD", driver: "Mike", type: "Arrival", datetime: "2025-10-22 09:00", status: "Driver Assigned", parkingSpot: "C07" },
  { no: 4, client: " Jim Carry", airport: "DFW", driver: "Ryan", type: "Departure", datetime: "2025-10-22 12:30", status: "Driver Assigned", parkingSpot: "D15" },
  { no: 5, client: "Lisa Anderson", airport: "JFK", driver: "Chris", type: "Arrival", datetime: "2025-10-23 08:15", status: "Driver not Assigned", parkingSpot: "E01" },
  { no: 6, client: "Virat Kohli", airport: "LAX", driver: "Tom", type: "Departure", datetime: "2025-10-24 11:45", status: "Scheduled", parkingSpot: "F03" },
  { no: 7, client: "James Bond", airport: "ORD", driver: "Steve", type: "Arrival", datetime: "2025-10-25 15:30", status: "Driver Assigned", parkingSpot: "G21" },
  { no: 8, client: "Shahrukh Khan", airport: "ORD", driver: "Steve", type: "Arrival", datetime: "2025-10-25 15:30", status: "Driver Assigned", parkingSpot: "G21" }
];
