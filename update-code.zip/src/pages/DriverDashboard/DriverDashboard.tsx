import React from 'react';
const DriverDashboard: React.FC = () => (
  <div className="container mt-4"><h2>Driver Dashboard</h2><p>Assigned tasks and progress.</p></div>
);
export default DriverDashboard;