const BASE_URL = "http://localhost:5009";
// const BASE_URL = "http://145.79.1.236:5009"
export default BASE_URL;
