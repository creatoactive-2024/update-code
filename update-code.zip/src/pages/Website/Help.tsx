import React from 'react';

const Help: React.FC = () => (
  <div className="container mt-4">
    <h2>Help</h2><p>Help center.</p>
  </div>
);

export default Help;