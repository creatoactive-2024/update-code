import React from 'react';

const ContactUs: React.FC = () => (
  <div className="container mt-4">
    <h2>Contact Us</h2><p>Contact details.</p>
  </div>
);

export default ContactUs;