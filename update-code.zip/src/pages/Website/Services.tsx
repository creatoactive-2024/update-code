import React from 'react';

const Services: React.FC = () => (
  <div className="container mt-4">
    <h2>Services</h2><p>Our services.</p>
  </div>
);

export default Services;