import React from 'react';

const Coupons: React.FC = () => {
  return (
    <div>
      <h2>Coupons</h2>
      <p>Manage discount coupons for customers.</p>
    </div>
  );
};

export default Coupons;
