import React from 'react';

const Users: React.FC = () => {
  return (
    <div>
      <h2>Users</h2>
      <p>Manage all registered users here.</p>
    </div>
  );
};

export default Users;
