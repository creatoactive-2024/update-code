import React from 'react';

const Bookings: React.FC = () => {
  return (
    <div>
      <h2>Bookings</h2>
      <p>View and manage all bookings.</p>
    </div>
  );
};

export default Bookings;
